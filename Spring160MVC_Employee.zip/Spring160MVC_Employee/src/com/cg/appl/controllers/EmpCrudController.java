package com.cg.appl.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;
import com.cg.appl.services.EmpServices;


// htttp://localhost:8085/Spring120MVC_Login/login.do
@Controller
public class EmpCrudController
{
	private EmpServices services;
	//List<Integer> traineeIDs;
	
	/*@PostConstruct
	public void intialize()
	{
				
	}*/
	
	
		@Resource(name="EmpService") //service injection in controller
		public void setTraineeServices(EmpServices services)
		{
			this.services  = services;
		}
		
		@RequestMapping("/welcome.do")
		public ModelAndView getWelcomePage()
		{
			ModelAndView model = new ModelAndView("welcome");
			return model;
		}	
	
	
		@RequestMapping("/enterEmpNo.do")
		public ModelAndView enterEmpNo()
		{
			ModelAndView model = new ModelAndView("enterEmpNo");
			return model;
		}
		
		//
		@RequestMapping("/getEmpDetails.do") 	//here input parameter must be mapped to textfields in login.jsp file form
		public ModelAndView getEmpDetails(@RequestParam("empNo") int empNo)
		{
			System.out.println("Emp No : "+empNo);
			
			Emp emp;
			ModelAndView model = null;
			try {
				emp = services.getEmpDetails(empNo);
				
				model = new ModelAndView("empDetails");
				model.addObject("empDetails",emp);
				
			} catch (EmpException e) {				
				model = new ModelAndView("error");
				model.addObject("errMsg", e.getMessage());
			}			
			return model;
		}
		
		@RequestMapping("/listAllEmps.do")
		public ModelAndView listAllEmps()
		{
			
			ModelAndView model = null;
			try 
			{				
				List<Emp> tList = services.getAllEmps();
				model = new ModelAndView("listAllEmps");
				model.addObject("emps", tList);
			}
			catch (EmpException e)
			{
				model = new ModelAndView("error");
				model.addObject("errMsg", e.getMessage());				
			}			 
			return model;
		}
				
		@RequestMapping("entryForm.do")
		public ModelAndView getEntryForm()
		{
			ModelAndView model = new ModelAndView("entryForm");
			model.addObject("emp", new Emp());
			
			 /* object creation for submitEntryForm.do which is fetched in @ModelAttribute
			 */ 
			return model;
		}
		
		@RequestMapping("/getUpdateForm.do") 	//here input parameter must be mapped to textfields in login.jsp file form
		public ModelAndView getUpdateForm(@RequestParam("id") int empNo)
		{
			System.out.println("Emp No : "+empNo);
			
			Emp emp;
			ModelAndView model = null;
			try {
				emp = services.getEmpDetails(empNo);
				
				model = new ModelAndView("updateEmpForm");
				model.addObject("empDetails",emp);
				
			} catch (EmpException e) {				
				model = new ModelAndView("error");
				model.addObject("errMsg", e.getMessage());
			}			
			return model;
		}
		
		@RequestMapping("/submitUpdateForm.do")
		public ModelAndView updateTraineeDetails(@ModelAttribute("empDetails") @Valid Emp emp, BindingResult result)
		{
			 ModelAndView model = new ModelAndView("successUpdate");
			 if(result.hasErrors())
				{
					//System.out.println("bhsdfbhlsdvbhsdv");
					model.addObject("empDetails");
					model.setViewName("updateEmpForm");
					return model;
				}
			 else
			 {
					try {
						Emp empResponse = services.updateEmpDetails(emp);
		
						model.addObject("empDetails",empResponse);
						
					} catch (EmpException e) {
						model.addObject("errMsg", "Unable to update Emp : "+emp.getEmpNo());
						model.setViewName("error");
					}			
					return model;
			 }
		}
		
		@RequestMapping("/deleteEmpDetails.do")
		public ModelAndView deleteEmpDetails(@RequestParam("id") int empNo)
		{
			ModelAndView model  = new ModelAndView();
			try {
				Emp empResponse = services.deleteEmpDetails(empNo);
				
					System.out.println("Employee "+empNo+" deleted !!!");
					model.addObject("empDetails",empResponse);
					model.setViewName("successDelete");
								
			} catch (EmpException e) {
				model.addObject("errMsg", "Unable to delete Employee : "+empNo);
				model.setViewName("error");
			}			
			return model;
		}
		
		@RequestMapping("/getInsertForm.do")
		public ModelAndView getInsertForm()
		{
			ModelAndView model  = new ModelAndView("entryForm");
			model.addObject("emp", new Emp());
			return model;
		}
		
		@RequestMapping("/insertEmpDetails.do")
		public ModelAndView insertEmpDetails(@ModelAttribute("emp") @Valid Emp emp, BindingResult result)
		{
			ModelAndView model  = new ModelAndView("successInsert");
			if(result.hasErrors())
			{
				model.addObject("emp");
				model.setViewName("entryForm");
				return model;
			}
			else
			{
				try {
						Emp empResponse = services.insertNewEmp(emp);
					
						System.out.println("Employee "+emp.getEmpNo()+" inserted !!!");
						model.addObject("empDetails",empResponse);
									
				} catch (EmpException e) {
					model.addObject("errMsg", "Unable to insert Employee : "+emp.getEmpNo());
					model.setViewName("error");
				}
				return model;
			}
			
		}
		
		/*
		@RequestMapping("submitEntryFrom.do")
		public ModelAndView submitEntryForm(@ModelAttribute @Valid Emp emp, BindingResult result) 	//generates emp obj based on jsp page
		{
			ModelAndView model  = new ModelAndView();
			
			if(result.hasErrors())
			{
				//System.out.println("bhsdfbhlsdvbhsdv");
				//model.addObject("trainee", new Trainee());
				model.setViewName("entryForm");
				return model;
			}
			else
			{	
				try {
					Emp empResponse = services.insertNewEmp(emp);			
					
					model.setViewName("successInsert");
					model.addObject("trainee", empResponse);
					
				} catch (EmpException e) {
					model.setViewName("errorInsert");
					model.addObject("errMsg", "Record insertion failure !!!"+e.getMessage());
				}
				return model;
			}
		}
		
		
				
		@RequestMapping("/enterTraineeNoToDelete.do")
		public ModelAndView enterTraineeNoToDelete()
		{
			ModelAndView model = new ModelAndView("deleteTrainee");
			return model;
		}
			
		@RequestMapping("/deleteTraineeDetails.do")
		public ModelAndView deleteTrainee(@RequestParam("traineeNo") int traineeNo)
		{
			ModelAndView model  = new ModelAndView();
			try {
				boolean isDeleted = services.deleteTraineeDetails(traineeNo);
				if(isDeleted)
				{
					System.out.println("Trainee "+traineeNo+" deleted !!!");
					model.setViewName("welcome");
				}
				else
				{
					model.addObject("errMsg", "Unable to delete Trainee : "+traineeNo);
					model.setViewName("error");
				}
				
				
			} catch (TraineeException e) {
				model.addObject("errMsg", "Unable to delete Trainee : "+traineeNo);
				model.setViewName("error");
			}			
			return model;
		}
		
		*/
}