package com.cg.appl.daos;

import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.RollbackException;

import org.springframework.stereotype.Repository;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;

@Repository("EmpDao")
public class EmpDaoImpl implements EmpDao {

	@PersistenceContext
	private EntityManager manager;
	
	//private EntityManagerFactory factory;
	
	/*@Resource(name="entityMFactory")
	public void setEntityMFactory(EntityManagerFactory factory)
	{
		this.factory = factory;
	}*/
	
	@Override
	public Emp getEmpDetails(int empId) throws EmpException {
		//EntityManager manager = factory.createEntityManager();
		
		Emp emp = manager.find(Emp.class, empId);		
		return emp;
	}

	@Override
	public List<Emp> getAllEmps() throws EmpException {
		
		//EntityManager manager = factory.createEntityManager();
		Query	query = manager.createNamedQuery("qryAllEmps", Emp.class);
			
		return query.getResultList();
	}

	@Override
	public Emp insertNewEmp(Emp emp) throws EmpException, RollbackException {
		
		manager.persist(emp);
		
		return emp;
	}

	@Override
	public Emp deleteEmpDetails(int empNo) throws EmpException,
			RollbackException {
		
		//EntityManager manager = factory.createEntityManager();
		
		try {
			//manager.getTransaction().begin();
			
			Emp emp = manager.find(Emp.class, empNo);
			System.out.println(emp);
			manager.remove(emp);
			
			//manager.getTransaction().commit();		
			return emp;
		} catch (RollbackException e) {
			
			throw new EmpException("Employee deletion failure !!!"+e);
		}
		
	}

	@Override
	public Emp updateEmpDetails(Emp emp) throws EmpException,
			RollbackException {
		
		//EntityManager manager = factory.createEntityManager();
		try {
			//manager.getTransaction().begin();
			
			manager.merge(emp);
						
			//manager.getTransaction().commit();		
			return emp;
		} catch (RollbackException e) {
			
			throw new EmpException("Emp updation failure !!!"+e);
		}
	}

	/*@Override
	public Emp insertNewEmp(Emp emp) throws EmpException {
		
		EntityManager manager = factory.createEntityManager();
		
		//programatic trasaction management
		try {
			manager.getTransaction().begin();
			manager.persist(emp); //inserts data in table and returns the trainee object
			manager.getTransaction().commit();
			
		} catch (RollbackException e) {
			manager.getTransaction().rollback();
			throw new EmpException("Record not commited",e);
		}
		
		if(trainee!=null)
		{
			System.out.println("Trainee : "+trainee.getTraineeName()+" inserted.");
		}
		
		return trainee;
	}

	@Override
	public boolean deleteTraineeDetails(int traineeId) throws TraineeException {
		
		EntityManager manager = factory.createEntityManager();
		
		try {
			manager.getTransaction().begin();
			
			Trainee trainee = manager.find(Trainee.class, traineeId);
			System.out.println(trainee);
			manager.remove(trainee);
			
			manager.getTransaction().commit();		
			return true;
		} catch (RollbackException e) {
			
			throw new TraineeException("Trainee deletion failure !!!"+e);
		}
	}

	@Override
	public boolean updateTraineeDetails(Trainee trainee)
			throws TraineeException {
		EntityManager manager = factory.createEntityManager();
		try {
			manager.getTransaction().begin();
			
			manager.merge(trainee);
						
			manager.getTransaction().commit();		
			return true;
		} catch (RollbackException e) {
			
			throw new TraineeException("Trainee updation failure !!!"+e);
		}
		//return false;
	}
	*/
	

}