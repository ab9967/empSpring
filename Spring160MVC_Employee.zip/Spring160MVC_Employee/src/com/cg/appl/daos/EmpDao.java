package com.cg.appl.daos;

import java.util.List;

import javax.persistence.RollbackException;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;

public interface EmpDao
{
		Emp getEmpDetails(int empId) throws EmpException;
		
		List<Emp>	getAllEmps() throws EmpException;
		
		Emp insertNewEmp(Emp emp) throws EmpException, RollbackException;
		
		Emp deleteEmpDetails(int empNo) throws EmpException, RollbackException;
		
		Emp updateEmpDetails(Emp emp) throws EmpException, RollbackException;
}
